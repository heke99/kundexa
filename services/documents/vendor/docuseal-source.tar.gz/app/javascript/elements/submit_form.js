export default class extends HTMLElement {
  connectedCallback () {
    if (this.lastElementChild) {
      this.init()
    } else {
      queueMicrotask(() => this.init())
    }
  }

  disconnectedCallback () {
    if (this.interval) {
      clearInterval(this.interval)
    }
  }

  init () {
    const form = this.querySelector('form') || (this.querySelector('input, button, select') || this.lastElementChild).form

    if (this.dataset.interval) {
      this.interval = setInterval(() => {
        form.requestSubmit()
      }, parseInt(this.dataset.interval))
    } else if (this.dataset.on) {
      this.lastElementChild.addEventListener(this.dataset.on, (event) => {
        if (this.dataset.disable === 'true') {
          form.querySelector('[type="submit"]')?.setAttribute('disabled', true)
        }

        if (this.dataset.submitIfValue === 'true') {
          if (event.target.value) {
            form.requestSubmit()
          }
        } else {
          form.requestSubmit()
        }
      })
    } else {
      form.requestSubmit()
    }
  }
}
